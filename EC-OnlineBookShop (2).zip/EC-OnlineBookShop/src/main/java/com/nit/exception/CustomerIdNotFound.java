package com.nit.exception;

public class CustomerIdNotFound extends RuntimeException{

	
	private static final long serialVersionUID = 1L;

	public CustomerIdNotFound(String msg) {
		super(msg);
	}

	
	
	

}
