package com.nit.utility;

public class Constants {
	
	public  static final String SUCESS="sucess";
	public  static final String FAILURE="failure";
	public  static final String FAILED="failed";

}
