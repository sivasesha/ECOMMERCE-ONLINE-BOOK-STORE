package com.nit.service;

import org.springframework.web.multipart.MultipartFile;

public interface BooksUploadExcelserv {
	
	public void uploadExcel(MultipartFile file);

}
