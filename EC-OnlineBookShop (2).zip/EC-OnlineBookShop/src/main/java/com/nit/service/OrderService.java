package com.nit.service;

import com.nit.model.OrdersModuleDto;

public interface OrderService {
	
	public String saveOrder(OrdersModuleDto orderModuleDto);

}
