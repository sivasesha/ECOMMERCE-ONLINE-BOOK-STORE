package com.nit.service;

import com.nit.model.ReviewDto;

public interface ReviewService {

	
	public String createRatingReview(ReviewDto reviewDto);
	
	
}
