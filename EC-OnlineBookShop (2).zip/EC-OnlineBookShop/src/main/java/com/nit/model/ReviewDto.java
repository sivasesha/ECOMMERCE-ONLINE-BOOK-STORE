package com.nit.model;

import lombok.Data;

@Data
public class ReviewDto {
	
	private Integer custId;
	private Integer bookId;
	private Integer rate;
	private String review;
	


	

	

}
