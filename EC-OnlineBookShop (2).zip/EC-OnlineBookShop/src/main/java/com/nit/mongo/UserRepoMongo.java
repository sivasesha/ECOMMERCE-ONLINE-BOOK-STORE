package com.nit.mongo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.mongodb.repository.MongoRepository;

import com.nit.entity.UserRegistration;
import com.nit.entity.mongo.UserRegistrationMongo;


public interface UserRepoMongo extends MongoRepository<UserRegistrationMongo, String> {

	

}
