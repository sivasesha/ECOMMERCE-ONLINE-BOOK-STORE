package com.nit.serviceImpl;

import org.springframework.web.multipart.MultipartFile;

import com.nit.service.BooksUploadExcelserv;

public class BooksUploadExcelServImpl implements BooksUploadExcelserv {

	@Override
	public void uploadExcel(MultipartFile file) {
		
	}

}
