package com.nit.main;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nit.controller.BooksController;
import com.nit.entity.Books;
import com.nit.serviceImpl.BooksServiceImpl;

@WebMvcTest(BooksController.class)
public class BooksControllerTest {
	
	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private BooksServiceImpl booksServiceImpl;
	
	@Autowired
	private ObjectMapper objectMapper;
	
	@Test
	public void testCustomeSaveBooks() throws  Exception {
		Books books=new Books();
		books.setId(12);
		books.setName("java");
		books.setTitle("java");
		
		Books books1=new Books();
		books1.setId(12);
		books1.setName("java");
		books1.setTitle("java");
		
		when(booksServiceImpl.saveCustomerBooks(books)).thenReturn(books1);
		
		mockMvc.
		perform(post("/books/saveBooks").
				contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(books1)))
		.andExpect(status().isOk());

		
		
		
	}
	
	@Test
	public void testgetAllBooksOfCustomer() throws Exception {
		
		Books books=new Books();
		books.setId(12);
		books.setName("java");
		books.setTitle("java");
		
		Books books1=new Books();
		books1.setId(12);
		books1.setName("java");
		books1.setTitle("java");
		
		List<Books> list = Arrays.asList(books,books1);
		
when(booksServiceImpl.getAllCustomerBooks()).thenReturn(list);
		
		mockMvc.
		perform(get("/books/getAllBooks").
				contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(list)))
		.andExpect(status().isOk());

		
	}
	
	@Test
	public void testgetCustomerBookbyIds() throws Exception {
		int id=12;
		Books books=new Books();
		books.setId(123);
		books.setName("java");
		books.setTitle("java");
		books.setAuthor("siva");
		
when(booksServiceImpl.getCustomerBookById(id)).thenReturn(books);
		
		mockMvc.
		perform(get("/books/getbook/{id}",id)).
		andExpect(status().isOk());

	}

}
