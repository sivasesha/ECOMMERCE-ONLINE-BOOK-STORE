package com.nit.main;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.lang.runtime.ObjectMethods;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nit.controller.CustomerController;
import com.nit.entity.Customer;
import com.nit.serviceImpl.CustomerServiceImpl;

@WebMvcTest(CustomerController.class)
public class CustomerControllerTest {
	
	@Autowired
	private MockMvc mockMvc;
	
	@Autowired
	private ObjectMapper objectMapper;
	
	@MockBean
	private CustomerServiceImpl customerServiceImpl;
	
	
	@Test
	public void testCustomerRegsitration() throws Exception {
		
		Customer cust=new Customer();
		cust.setId(1);
		cust.setName("sesha");
		cust.setEmail("seaha@gmail.com");
		
		Customer cust1=new Customer();
		cust1.setId(1);
		cust1.setName("sesha");
		cust1.setEmail("seaha@gmail.com");
		
		when(customerServiceImpl.customerSave(cust)).thenReturn(cust1);
		
		mockMvc.
		perform(post("/customer/customerSave").
				contentType(MediaType.APPLICATION_JSON)
          .content(objectMapper.writeValueAsString(cust1))).
		andExpect(status().isCreated());			
		
		
	}
	
	
	@Test
	public void testUpadteCustomer() throws  Exception {
		
		Customer cust=new Customer();
		cust.setId(1);
		cust.setEmail("sesha@123");
		cust.setName("sesha");
		
		Customer Update=new Customer();
		Update.setId(1);
		Update.setEmail("sesha@123");
		Update.setName("sesha");
		when(customerServiceImpl.customerUpdate(cust)).thenReturn(Update);
		
		mockMvc.
		perform(put("/customer/updateCustomerDetails").
				contentType(MediaType.APPLICATION_JSON)
          .content(objectMapper.writeValueAsString(cust))).
		andExpect(status().isCreated());	
		
		
	}
	
	@Test
	public void testCustomerSaveorUpdate() throws  Exception {
		
		Customer cust=new Customer();
		cust.setId(1);
		cust.setEmail("sesha@123");
		cust.setName("sesha");
		
		Customer Update=new Customer();
		Update.setId(1);
		Update.setEmail("sesha@123");
		Update.setName("sesha");
		when(customerServiceImpl.customerUpdate(cust)).thenReturn(Update);
		
		mockMvc.
		perform(post("/customer/customerSaveorupdate").
				contentType(MediaType.APPLICATION_JSON)
          .content(objectMapper.writeValueAsString(cust))).
		andExpect(status().isCreated());	
		
		
	}
	
	@Test
	public void testCustomerDeatils() throws  Exception {
		
		Customer cust=new Customer();
		int id=1;
		cust.setId(1);
		cust.setEmail("sesha@123");
		cust.setName("sesha");
		
		when(customerServiceImpl.customerfindById(id)).thenReturn(cust);
		
		mockMvc.
		perform(get("/customer/customerFindById/{id}",id)).
		andExpect(status().isCreated());	
		
		
	}
	
	@Test
	public void testCustomerAllDeatils() throws JsonProcessingException, Exception {
		Customer cust1=new Customer();
		cust1.setId(1);
		cust1.setEmail("sesha@gmail.com");
		cust1.setName("sesha");
		
		Customer cust2=new Customer();
		cust2.setId(1);
		cust2.setEmail("sesha@gmail.com");
		cust2.setName("sesha");
		
		List<Customer> list = Arrays.asList(cust1,cust2);
		
		when(customerServiceImpl.customersAll()).thenReturn(list);
		
		mockMvc.
		perform(get("/customer/customersAllDetails").
				contentType(MediaType.APPLICATION_JSON)
          .content(objectMapper.writeValueAsString(list))).
		andExpect(status().isCreated());	
		
		
	}

}
