package com.nit.main;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nit.controller.UserController;
import com.nit.entity.UserRegistration;
import com.nit.model.UserRequestDTO;
import com.nit.serviceImpl.UserRegistrationServiceImpl;

@WebMvcTest(UserController.class)
public class UserRegistrationTest {
	
	
	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private UserRegistrationServiceImpl userService;
	
	@Autowired
    private ObjectMapper objectMapper;
	
	@Test
	public void testregisterUser() throws Exception {
		
		//input 
		
		
		UserRequestDTO userDto= new UserRequestDTO();
		userDto.setEmail("sesha@gamil.com");
		userDto.setPwd("1234");
		
		//MockService
		
		UserRegistration mock=new UserRegistration();
		
		mock.setId(23L);
		mock.setEmail("sesha@gamil.com");
		
		//mock service call
		
		when(userService.insertUser(userDto)).thenReturn(mock);
		
		//perform validation
		mockMvc.perform(post("/user/userRegister")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(userDto)))
                .andExpect(status().isCreated());
	}
	
	@Test
	public void testcheckUserDeatils() throws  Exception {
		UserRequestDTO user=new UserRequestDTO();
		 user.setEmail("sesha1@gamil.com");
		 user.setPwd("12345");
		UserRegistration userRegistration=new UserRegistration();
		userRegistration.setEmail("sesha1@gamil.com");
		userRegistration.setPwd("12345");
		
		when(userService.checkUser(user)).thenReturn(userRegistration);
		
		mockMvc.
		perform(post("/user/userLogin")
				.contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(user))).
		andExpect(status().isOk());
		
	}

}
